# DayTrading AI Pro — Paper Trading Edition

Responsive Hebrew-first dashboard with a local strategy lab, illustrative stock scanner, position-sizing calculator, and a server-side **read-only** Trading 212 Demo connection.

## Important scope / API accuracy

- The backend is hard-locked to `https://demo.trading212.com/api/v0`.
- Implemented Trading 212 routes are read-only: account summary, open positions, and instrument metadata.
- It does **not** send, cancel, or modify orders, and it has no live-trading URL or order-placement code.
- The candlestick chart and scanner scores are **synthetic demo examples**. They are not live prices, recommendations, or predictions. Trading 212's listed endpoints used here do not provide a real-time quote/candle feed, so the UI labels them accordingly.
- API keys stay in server environment variables and are never accepted by the browser or returned by the backend.
- Trading 212 Public API is in beta and availability depends on account type, permissions, and whether demo credentials are generated separately.

Official docs: https://docs.trading212.com/api/section/authentication

## Run locally

Requires Python 3.10+.

### Windows

```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
python app.py
```

### macOS / Linux / Android Termux

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
python app.py
```

Then open `http://127.0.0.1:5000` on the same device. On Android, use Termux from a trusted source, install Python, then run the commands above. Localhost is only reachable on that device unless you intentionally configure networking.

## Configure Trading 212 Demo

1. In Trading 212, open API settings and review the permissions and risk warning.
2. Generate credentials for the **demo/paper environment**, if available for your account.
3. Open `.env` on the server and fill in:

```dotenv
TRADING212_API_KEY=your_demo_key
TRADING212_API_SECRET=your_demo_secret
PORT=5000
```

4. Restart the app and click **בדוק חיבור**. A valid key with read permissions should return the demo account summary. The app does not need order permissions.
5. Do not paste secrets into chat, source code, GitHub, a browser form, screenshots, or public logs. If a secret is exposed, revoke/rotate it in Trading 212.

## Deploy

A `render.yaml` and `Procfile` are included for a Python web service. For a Render-style deployment:

1. Push this folder to a private GitHub repository (do not commit `.env`).
2. Create a new web service from that repository.
3. Add `TRADING212_API_KEY` and `TRADING212_API_SECRET` using the host's secret/environment-variable settings.
4. Deploy, then check `/api/health` and the site.
5. Use only demo credentials and read-only permissions. Hosting providers may have dynamic IPs, which can conflict with Trading 212 IP allowlists. Review the provider's outbound IP guidance before configuring allowlists.

Do not deploy a service with real-money keys. This project intentionally provides no order execution feature.

## Strategy lab

- EMA 9 / EMA 21 comparison and a simplified RSI calculation on synthetic close prices.
- Optional synthetic momentum mode.
- Scanner rows are fixed illustrative scores, not market data.
- Risk calculator estimates a hypothetical quantity from account size, risk percentage, entry, and stop distance. It does not submit trades and omits fees, slippage, gaps, and liquidity effects.

## API endpoints in this app

- `GET /api/health` — backend state and whether server-side credentials are configured (never returns the values).
- `GET /api/trading212/summary` — `GET /equity/account/summary` from the demo base.
- `GET /api/trading212/positions` — `GET /equity/positions` from the demo base.
- `GET /api/trading212/instruments` — `GET /equity/metadata/instruments` from the demo base.

## Before public use

This starter is designed for local/personal demo use. A public deployment should add authentication, CSRF protections for any future state-changing routes, stricter rate limiting, monitoring, and a managed secret store. Never add order endpoints without a separate design and review.
