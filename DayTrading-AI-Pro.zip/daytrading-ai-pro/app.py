from flask import Flask, jsonify, render_template, request
from dotenv import load_dotenv
import os, requests
from requests.auth import HTTPBasicAuth

load_dotenv()
app = Flask(__name__)

# Intentionally hard-locked to Trading 212 PAPER/DEMO API. No live trading endpoints.
T212_BASE = "https://demo.trading212.com/api/v0"
TIMEOUT = 12


def t212_get(path):
    key = os.getenv("TRADING212_API_KEY", "").strip()
    secret = os.getenv("TRADING212_API_SECRET", "").strip()
    if not key or not secret:
        return None, "API credentials are not configured. Add them to .env on the server."
    try:
        response = requests.get(
            T212_BASE + path,
            auth=HTTPBasicAuth(key, secret),
            headers={"Accept": "application/json", "User-Agent": "DayTradingAIPro-Paper/1.0"},
            timeout=TIMEOUT,
        )
        if response.status_code == 401:
            return None, "Authentication failed. Check the demo API key and secret."
        if response.status_code == 403:
            return None, "Access denied. Check that the key belongs to the demo environment and has read permissions."
        if response.status_code == 429:
            return None, "Trading 212 rate limit reached. Wait before retrying."
        response.raise_for_status()
        return response.json(), None
    except requests.Timeout:
        return None, "Trading 212 request timed out. Try again later."
    except requests.RequestException as exc:
        # Avoid returning headers, credentials, or request internals to the browser.
        return None, f"Trading 212 request failed ({type(exc).__name__})."
    except ValueError:
        return None, "Trading 212 returned a response that was not valid JSON."


@app.get("/")
def index():
    return render_template("index.html")

@app.get("/api/health")
def health():
    configured = bool(os.getenv("TRADING212_API_KEY", "").strip() and os.getenv("TRADING212_API_SECRET", "").strip())
    return jsonify({"ok": True, "mode": "paper-only", "credentialsConfigured": configured,
                    "message": "Paper-only backend. This app does not submit orders."})

@app.get("/api/trading212/summary")
def account_summary():
    data, error = t212_get("/equity/account/summary")
    if error:
        return jsonify({"ok": False, "error": error}), 400
    return jsonify({"ok": True, "data": data})

@app.get("/api/trading212/positions")
def positions():
    data, error = t212_get("/equity/positions")
    if error:
        return jsonify({"ok": False, "error": error}), 400
    return jsonify({"ok": True, "data": data})

@app.get("/api/trading212/instruments")
def instruments():
    # Trading 212 metadata, not a live quote feed.
    data, error = t212_get("/equity/metadata/instruments")
    if error:
        return jsonify({"ok": False, "error": error}), 400
    return jsonify({"ok": True, "data": data})

@app.errorhandler(404)
def not_found(_):
    return jsonify({"ok": False, "error": "Not found"}), 404

if __name__ == "__main__":
    # Local development only. For public deployment use a production WSGI server.
    app.run(host="127.0.0.1", port=int(os.getenv("PORT", "5000")), debug=False)
